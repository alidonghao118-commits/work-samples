"""A source-bound quote check, with synthetic examples and regression tests.

Run: python quote_review.py
No network, model, credentials, or third-party packages are used.
"""
import json
import unittest
from dataclasses import dataclass


@dataclass(frozen=True)
class Message:
    direction: str
    text: str


def load_messages(raw: str) -> dict[str, Message]:
    """Decode an export produced by the trusted message collector."""
    rows = json.loads(raw)
    if not isinstance(rows, list):
        raise ValueError('Expected a list of messages')
    result = {}
    for row in rows:
        if not isinstance(row, dict) or set(row) != {'id', 'direction', 'text'}:
            raise ValueError('Invalid message schema')
        if not all(isinstance(row[k], str) and row[k] for k in row):
            raise ValueError('Message fields must be nonempty strings')
        if row['direction'] not in {'inbound', 'outbound'}:
            raise ValueError('Unknown message direction')
        if row['id'] in result:
            raise ValueError('Duplicate message ID')
        result[row['id']] = Message(row['direction'], row['text'])
    return result


def check_candidate(candidate: dict, sources: dict[str, Message]) -> dict:
    """Validate attribution before review; this never authorizes an action."""
    if not isinstance(candidate, dict) or set(candidate) != {'source_id', 'quote'}:
        raise ValueError('Expected source_id and quote only')
    source_id, quote = candidate['source_id'], candidate['quote']
    if not isinstance(source_id, str) or source_id not in sources:
        raise ValueError('Unknown source ID')
    if not isinstance(quote, str) or not 1 <= len(quote) <= 240:
        raise ValueError('Invalid quote length')
    source = sources[source_id]
    if source.direction != 'inbound':
        raise ValueError('An outgoing message is not customer evidence')
    start = source.text.find(quote)
    if start < 0:
        raise ValueError('Quote is not a contiguous source span')
    return {'source_id': source_id, 'start': start, 'end': start + len(quote),
            'quote': source.text[start:start + len(quote)], 'status': 'review'}


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.rows = [
            {'id': 'in-1', 'direction': 'inbound',
             'text': 'Please fix the export.\nKeep the café column.'},
            {'id': 'out-1', 'direction': 'outbound',
             'text': 'Please approve the estimate.'},
            {'id': 'in-2', 'direction': 'inbound', 'text': 'The export'},
            {'id': 'in-3', 'direction': 'inbound', 'text': 'is approved.'},
        ]
        self.sources = load_messages(json.dumps(self.rows, ensure_ascii=True))

    def test_decoded_newline_and_unicode(self):
        quote = self.rows[0]['text']
        raw = json.dumps(self.rows, ensure_ascii=True)
        self.assertNotIn(quote, raw)
        result = check_candidate({'source_id': 'in-1', 'quote': quote}, self.sources)
        self.assertEqual(result['quote'], quote)
        self.assertEqual(result['status'], 'review')

    def test_outgoing_exact_quote_rejected(self):
        with self.assertRaisesRegex(ValueError, 'outgoing'):
            check_candidate({'source_id': 'out-1', 'quote': self.rows[1]['text']}, self.sources)

    def test_cross_message_stitch_rejected(self):
        with self.assertRaisesRegex(ValueError, 'contiguous'):
            check_candidate({'source_id': 'in-2', 'quote': 'The export is approved.'}, self.sources)

    def test_changed_words_rejected(self):
        with self.assertRaisesRegex(ValueError, 'contiguous'):
            check_candidate({'source_id': 'in-1', 'quote': 'Please ship the export.'}, self.sources)

    def test_unknown_source_rejected(self):
        with self.assertRaisesRegex(ValueError, 'Unknown source'):
            check_candidate({'source_id': 'missing', 'quote': 'Please fix'}, self.sources)

    def test_empty_quote_rejected(self):
        with self.assertRaisesRegex(ValueError, 'quote length'):
            check_candidate({'source_id': 'in-1', 'quote': ''}, self.sources)

    def test_duplicate_source_id_rejected(self):
        with self.assertRaisesRegex(ValueError, 'Duplicate'):
            load_messages(json.dumps(self.rows + [self.rows[0]]))

    def test_model_cannot_supply_direction(self):
        with self.assertRaisesRegex(ValueError, 'source_id and quote only'):
            check_candidate({'source_id': 'out-1', 'quote': self.rows[1]['text'],
                             'direction': 'inbound'}, self.sources)

    def test_exact_negated_statement_still_requires_review(self):
        sources = {'in-4': Message('inbound', 'The estimate is not approved.')}
        result = check_candidate({'source_id': 'in-4', 'quote': sources['in-4'].text}, sources)
        self.assertEqual(result['status'], 'review')
        self.assertNotIn('approved', result)


if __name__ == '__main__':
    unittest.main(verbosity=2)
