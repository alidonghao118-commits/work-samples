import tempfile
from pathlib import Path
import unittest
from app import Store, validate_draft

EMAIL = {'id': 'm1', 'sender': 'a@example.test', 'subject': 'Question', 'body': 'How can I update my email?'}
DRAFT = {'summary': 'User asks how to update their email.', 'category': 'account', 'priority': 'normal', 'next_action': 'Explain account email update steps.'}


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.store = Store(Path(self.temp.name) / 'inbox.sqlite')
        self.addCleanup(self.temp.cleanup)

    def test_drafts_never_create_tickets_until_review(self):
        self.store.ingest([EMAIL])
        with self.assertRaises(ValueError):
            self.store.review('m1', 'approve')
        self.store.triage(lambda _: DRAFT)
        self.assertEqual(self.store.snapshot()['tickets'], [])
        changed = dict(DRAFT, next_action='Verify account ownership, then provide update instructions.')
        self.store.review('m1', 'approve', changed)
        snapshot = self.store.snapshot()
        self.assertEqual(snapshot['tickets'][0]['payload']['next_action'], changed['next_action'])
        self.assertEqual(snapshot['tickets'][0]['payload']['subject'], EMAIL['subject'])

    def test_replayed_approval_returns_same_ticket(self):
        self.store.ingest([EMAIL])
        self.store.triage(lambda _: DRAFT)
        first = self.store.review('m1', 'approve')
        second = self.store.review('m1', 'approve')
        self.assertEqual(first['ticket_id'], second['ticket_id'])
        self.assertTrue(second['already_created'])
        self.assertEqual(len(self.store.snapshot()['tickets']), 1)

    def test_message_id_and_identical_content_deduplication(self):
        result = self.store.ingest([EMAIL, EMAIL, dict(EMAIL, id='m2')])
        self.assertEqual(result, {'added': 1, 'duplicates': 2, 'quarantined': 0})
        calls = []
        self.store.triage(lambda e: (calls.append(e), DRAFT)[1])
        self.store.triage(lambda e: (calls.append(e), DRAFT)[1])
        self.assertEqual(len(calls), 1)

    def test_conflicting_id_and_malformed_records_preserved_in_quarantine(self):
        result = self.store.ingest([EMAIL, dict(EMAIL, body='Different message'), {'id':'bad'}, 'not an email'])
        self.assertEqual(result['quarantined'], 3)
        self.assertEqual(self.store.snapshot()['emails'][0]['payload']['body'], EMAIL['body'])

    def test_model_failure_is_retryable_and_no_ticket_exists(self):
        self.store.ingest([EMAIL])
        def failing(_):
            raise TimeoutError('Connection timed out')
        self.store.triage(failing)
        self.assertEqual(self.store.snapshot()['emails'][0]['state'], 'error')
        self.assertEqual(self.store.snapshot()['tickets'], [])
        self.store.triage(lambda _: DRAFT)
        row = self.store.snapshot()['emails'][0]
        self.assertEqual((row['state'], row['attempts']), ('draft', 2))

    def test_model_cannot_supply_approval_or_unknown_fields(self):
        self.store.ingest([EMAIL])
        self.store.triage(lambda _: dict(DRAFT, state='approved'))
        self.assertEqual(self.store.snapshot()['emails'][0]['state'], 'error')
        self.assertEqual(self.store.snapshot()['tickets'], [])
        with self.assertRaises(ValueError):
            validate_draft(dict(DRAFT, priority='execute'))

    def test_rejection_is_terminal_without_ticket(self):
        self.store.ingest([EMAIL])
        self.store.triage(lambda _: DRAFT)
        self.store.review('m1', 'reject')
        self.store.triage(lambda _: self.fail('Rejected record must not be reprocessed'))
        with self.assertRaises(ValueError):
            self.store.review('m1', 'approve')
        self.assertEqual(self.store.snapshot()['tickets'], [])

    def test_restart_retains_approved_ticket_and_duplicate_protection(self):
        self.store.ingest([EMAIL])
        self.store.triage(lambda _: DRAFT)
        self.store.review('m1', 'approve')
        reopened = Store(self.store.path)
        self.assertEqual(reopened.ingest([EMAIL])['duplicates'], 1)
        self.assertEqual(len(reopened.snapshot()['tickets']), 1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
