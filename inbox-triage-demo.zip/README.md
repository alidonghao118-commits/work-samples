# Inbox Review

An original, working mock-inbox prototype by Donghao Li. This is a portfolio sample built from fictional messages, not a previous client engagement.

Incoming email JSON → validated inbox → local model → editable draft → human approval → SQLite ticket.

## Run

Use Python 3.11+ and a local [Ollama](https://ollama.com/) installation. No Python packages are required.

```sh
ollama pull qwen3.5:9b
python app.py
```

Open http://127.0.0.1:8767. Click **Load example inbox**, then **Classify pending emails**. Select a message, review or edit the draft, and click **Approve & create ticket**. The queue and tickets persist in `inbox.sqlite`.

The example contains five distinct valid emails, two duplicates, and one malformed record. Loading it again skips existing messages; malformed attempts remain in the quarantine log. Custom mock input uses the same `id`, `sender`, `subject`, `body` JSON schema through `POST /api/ingest` with an `emails` array and the `X-Triage-UI: 1` header.

Use `--model`, `--endpoint`, `--port` or `--db` to choose a local model, service or separate database. The HTTP server deliberately listens only on loopback; use the displayed `127.0.0.1` address. The default model download is about 6.6 GB; runtime memory depends on hardware and context. Existing model installation can be reused.

## Review and failure behavior

- The model supplies only summary, category, priority and a suggested next action. Message identity and subject come from ingestion. Unknown model fields, including `state` or `approved`, are rejected.
- Categories and priorities are allowlisted. Drafts remain editable before approval.
- No ticket exists until the operator approves a draft. Approval writes a local ticket. Repeated approval returns the same ticket ID.
- Message IDs and exact sender/subject/body fingerprints prevent reprocessing the same email. Reusing an ID for different content places the new input in quarantine.
- Malformed or oversized messages are kept in quarantine. Model timeouts, unavailable endpoints or invalid JSON leave an error state that **Classify pending emails** retries.
- HTML in messages is displayed as text. Email content is untrusted model input and has no tool access or approval authority.

## Verification

```sh
python -m unittest -v
```

The tests cover approval gating, edited drafts, repeated approval, duplicate ingestion, conflicting IDs, malformed input, model failure/retry, unexpected model fields, rejection, and persistence across restarts. They use a stub model so workflow checks run offline. `live-model-check.json` records a separate run against the installed local model; its observed classifications are sample results, not a general accuracy benchmark.

## Scope

This version provides mock JSON ingestion, a local model adapter, review UI, local ticket storage and an automated test set. It has no Gmail OAuth connection, external CRM connection or outbound email transport. Those are separate integration steps. The single-process server is intended for local evaluation, not public multi-user hosting. Model calls use a 60-second timeout; large batches are processed sequentially. Quarantined records are available in SQLite for inspection.

Implementation references: [Ollama chat endpoint](https://docs.ollama.com/api/chat), [structured outputs](https://docs.ollama.com/capabilities/structured-outputs).

Copyright 2026 Donghao Li. Provided as a review sample; commercial reuse or customization can be agreed with the author.
