<?php
if (!defined('ABSPATH')) exit;
add_action('after_setup_theme', function () { add_theme_support('title-tag'); });
add_action('wp_enqueue_scripts', function () { wp_enqueue_style('object-studio', get_stylesheet_uri(), [], '1.0.0'); });
add_action('init', function () {
    register_post_type('studio_project', ['labels'=>['name'=>'Projects','singular_name'=>'Project'],'public'=>true,'show_in_rest'=>true,'supports'=>['title','editor','excerpt'],'menu_icon'=>'dashicons-format-gallery']);
    register_taxonomy('project_kind', 'studio_project', ['label'=>'Project categories','public'=>true,'show_in_rest'=>true,'hierarchical'=>true]);
    register_post_type('studio_inquiry', ['labels'=>['name'=>'Demo inquiries','singular_name'=>'Demo inquiry'],'public'=>false,'show_ui'=>true,'show_in_rest'=>false,'capability_type'=>'post','capabilities'=>['create_posts'=>'do_not_allow'],'map_meta_cap'=>true,'supports'=>['title','editor'],'menu_icon'=>'dashicons-email']);
});
function studio_submit_inquiry() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') wp_die('Please use the inquiry form.', '', ['response'=>405]);
    if (!isset($_POST['studio_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['studio_nonce'])), 'studio_inquiry')) wp_die('Please reload the form and try again.', '', ['response'=>403]);
    foreach (['name','email','service','brief','website'] as $field) {
        if (isset($_POST[$field]) && !is_string($_POST[$field])) wp_die('Please check the form fields.', '', ['response'=>400]);
    }
    if (!empty($_POST['website'])) wp_die('Please leave the website field empty.', '', ['response'=>400]);
    $name=sanitize_text_field(wp_unslash($_POST['name'] ?? ''));
    $email=sanitize_email(wp_unslash($_POST['email'] ?? ''));
    $service=sanitize_text_field(wp_unslash($_POST['service'] ?? ''));
    $brief=sanitize_textarea_field(wp_unslash($_POST['brief'] ?? ''));
    if (strlen($name)<2 || strlen($name)>100 || !is_email($email) || strlen($email)>200 || !in_array($service,['Product visualization','Game props','Something else'],true) || strlen($brief)<15 || strlen($brief)>3000) wp_die('Please enter a name, valid email, service and a brief of 15–3000 characters.', '', ['response'=>400]);
    $key='studio_rate_'.hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? 'local').wp_salt());
    if (get_transient($key)) wp_die('Your request was just saved. Please wait a minute before sending another.', '', ['response'=>429]);
    $id=wp_insert_post(['post_type'=>'studio_inquiry','post_status'=>'private','post_title'=>$name.' — '.$service,'post_content'=>"Email: $email\nService: $service\n\n$brief"],true);
    if (is_wp_error($id) || !$id) wp_die('Please try again in a moment.', '', ['response'=>500]);
    set_transient($key,1,60);
    wp_safe_redirect(add_query_arg('inquiry','saved', home_url('/')).'#quote',303); exit;
}
add_action('admin_post_nopriv_studio_inquiry','studio_submit_inquiry');
add_action('admin_post_studio_inquiry','studio_submit_inquiry');
function studio_image($filename) { return esc_url(get_template_directory_uri().'/assets/'.basename($filename)); }
