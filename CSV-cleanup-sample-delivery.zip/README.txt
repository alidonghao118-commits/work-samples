PRODUCT CSV CLEANUP - SAMPLE DELIVERY

All products and values in this example are fictional.

10 source records become 9 records after one exact duplicate is merged.
4 records pass the selected checks. 5 records need a decision.

FILES
01-original.csv: the untouched input.
02-processed-with-status.csv: all 9 records with their status and source references.
03-needs-your-review.csv: the 5 records needing a decision.
04-ready-records.csv: the 4 records passing this sample's checks.
result.json: processing output with unescaped processed values.
CSV-cleanup-sample.pdf: a one-page explanation of the result.

RULES APPLIED
Trim spaces. Standardize equivalent unit labels. Merge records only when all cleaned fields match. Check SKU, product name, recognized unit, non-negative price and whole-number stock.

DECISIONS NEEDED
0004: provide the missing price.
0005: two prices, 2 and 3, are retained. Confirm the correct product records.
Notebook: provide the missing SKU.
0006: confirm the negative stock value (-1).

Source records count data rows from 1, excluding the header.
Import the SKU column as Text in Excel to preserve leading zeros.
CSV exports protect formula-like values with an apostrophe; JSON retains unescaped processed values.

A live cleanup uses the customer's agreed fields and rules.
