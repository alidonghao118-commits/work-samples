package io.github.alidonghao118.starterkit;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import java.io.IOException;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class ClaimLedgerTest {
    @TempDir Path dir;
    final UUID id = UUID.fromString("781a9bab-d68b-4463-a9c2-64c98b175f61");

    @Test void firstClaimIsImmediatelyEligible() throws Exception {
        assertEquals(0, new ClaimLedger(dir.resolve("claims.properties")).secondsRemaining(id, 100, 86400));
    }
    @Test void survivesNewLedgerAndExpiresExactlyAtBoundary() throws Exception {
        Path path = dir.resolve("claims.properties");
        new ClaimLedger(path).record(id, 100);
        ClaimLedger reloaded = new ClaimLedger(path);
        assertEquals(1, reloaded.secondsRemaining(id, 159, 60));
        assertEquals(0, reloaded.secondsRemaining(id, 160, 60));
        assertEquals(0, reloaded.secondsRemaining(UUID.randomUUID(), 101, 60));
    }
    @Test void failedWriteDoesNotConsumeClaim() throws Exception {
        Path parent = dir.resolve("blocked");
        ClaimLedger ledger = new ClaimLedger(parent.resolve("claims.properties"));
        Files.writeString(parent, "not a directory");
        assertThrows(IOException.class, () -> ledger.record(id, 100));
        assertEquals(0, ledger.secondsRemaining(id, 101, 60));
    }
    @Test void damagedHistoryIsNotSilentlyReset() throws Exception {
        Path path = dir.resolve("claims.properties");
        Files.writeString(path, id + "=broken");
        assertThrows(IOException.class, () -> new ClaimLedger(path));
    }
    @Test void multiplePlayersAndLaterClaimArePreserved() throws Exception {
        Path path = dir.resolve("claims.properties");
        UUID other = UUID.randomUUID();
        ClaimLedger ledger = new ClaimLedger(path);
        ledger.record(id, 100); ledger.record(other, 200); ledger.record(id, 300);
        ClaimLedger reloaded = new ClaimLedger(path);
        assertEquals(60, reloaded.secondsRemaining(id, 300, 60));
        assertEquals(0, reloaded.secondsRemaining(other, 300, 60));
    }
    @Test void clockGoingBackwardsDoesNotUnlockKit() throws Exception {
        ClaimLedger ledger = new ClaimLedger(dir.resolve("claims.properties"));
        ledger.record(id, 100);
        assertEquals(60, ledger.secondsRemaining(id, 90, 60));
    }
}
