package io.github.alidonghao118.starterkit;

import org.junit.jupiter.api.*;
import org.mockbukkit.mockbukkit.MockBukkit;
import org.mockbukkit.mockbukkit.ServerMock;
import org.mockbukkit.mockbukkit.entity.PlayerMock;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import static org.junit.jupiter.api.Assertions.*;

class StarterKitPluginTest {
    ServerMock server;
    StarterKitPlugin plugin;
    PlayerMock player;
    @BeforeEach void setup() {
        server = MockBukkit.mock();
        plugin = MockBukkit.load(StarterKitPlugin.class);
        player = server.addPlayer();
    }
    @AfterEach void cleanup() { MockBukkit.unmock(); }

    int amount(Material material) {
        int count = 0;
        for (ItemStack item : player.getInventory().getStorageContents())
            if (item != null && item.getType() == material) count += item.getAmount();
        return count;
    }
    @Test void registeredCommandGivesExactKit() {
        assertTrue(plugin.isEnabled());
        assertTrue(server.dispatchCommand(player, "starterkit"));
        assertEquals(1, amount(Material.WOODEN_SWORD));
        assertEquals(1, amount(Material.WOODEN_PICKAXE));
        assertEquals(16, amount(Material.BREAD));
    }
    @Test void repeatedCommandDoesNotDuplicateItems() {
        server.dispatchCommand(player, "starterkit");
        server.dispatchCommand(player, "starterkit");
        assertEquals(1, amount(Material.WOODEN_SWORD));
        assertEquals(16, amount(Material.BREAD));
    }
    @Test void permissionDeniedDoesNotConsumeClaim() {
        var attachment = player.addAttachment(plugin, "starterkit.claim", false);
        server.dispatchCommand(player, "starterkit");
        assertEquals(0, amount(Material.BREAD));
        player.removeAttachment(attachment);
        server.dispatchCommand(player, "starterkit");
        assertEquals(16, amount(Material.BREAD));
    }
    @Test void insufficientRoomGivesNothingAndDoesNotConsumeClaim() {
        for (int i = 0; i < 34; i++) player.getInventory().setItem(i, new ItemStack(Material.STONE, 64));
        server.dispatchCommand(player, "starterkit");
        assertEquals(0, amount(Material.BREAD));
        assertEquals(0, amount(Material.WOODEN_SWORD));
        assertEquals(34 * 64, amount(Material.STONE));
        player.getInventory().clear(33);
        server.dispatchCommand(player, "starterkit");
        assertEquals(16, amount(Material.BREAD));
        assertEquals(33 * 64, amount(Material.STONE));
    }
    @Test void unknownArgumentsGiveUsageWithoutItems() {
        server.dispatchCommand(player, "starterkit admin");
        assertEquals(0, amount(Material.BREAD));
        server.dispatchCommand(player, "starterkit");
        assertEquals(16, amount(Material.BREAD));
    }
    @Test void consoleCommandDoesNotThrow() {
        assertDoesNotThrow(() -> server.dispatchCommand(server.getConsoleSender(), "starterkit"));
    }
    @Test void diskWriteFailureDoesNotGiveItems() throws Exception {
        var target = plugin.getDataFolder().toPath().resolve("claims.properties");
        java.nio.file.Files.createDirectory(target);
        java.nio.file.Files.writeString(target.resolve("block"), "test");
        server.dispatchCommand(player, "starterkit");
        assertEquals(0, amount(Material.BREAD));
        assertEquals(0, amount(Material.WOODEN_SWORD));
    }
}
