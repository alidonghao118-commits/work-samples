package io.github.alidonghao118.starterkit;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Durable claim timestamps; a failed save never mutates the in-memory ledger. */
final class ClaimLedger {
    private final Path file;
    private final Map<UUID, Long> claims = new HashMap<>();

    ClaimLedger(Path file) throws IOException {
        this.file = file;
        if (Files.exists(file)) {
            Properties p = new Properties();
            try (Reader in = Files.newBufferedReader(file)) { p.load(in); }
            try {
                for (String key : p.stringPropertyNames()) {
                    long timestamp = Long.parseLong(p.getProperty(key));
                    if (timestamp < 0) throw new IllegalArgumentException("Negative claim timestamp");
                    claims.put(UUID.fromString(key), timestamp);
                }
            } catch (IllegalArgumentException e) { throw new IOException("Invalid claims file", e); }
        }
    }

    long secondsRemaining(UUID player, long now, long cooldown) {
        Long last = claims.get(player);
        if (last == null) return 0;
        return Math.max(0, cooldown - Math.max(0, now - last));
    }

    void record(UUID player, long now) throws IOException {
        Map<UUID, Long> next = new HashMap<>(claims);
        next.put(player, now);
        Properties p = new Properties();
        next.forEach((id, value) -> p.setProperty(id.toString(), value.toString()));
        Files.createDirectories(file.getParent());
        Path temp = Files.createTempFile(file.getParent(), "claims-", ".tmp");
        try {
            try (Writer out = Files.newBufferedWriter(temp)) { p.store(out, "StarterKitDemo claim timestamps"); }
            Files.move(temp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            claims.clear(); claims.putAll(next);
        } finally { Files.deleteIfExists(temp); }
    }
}
