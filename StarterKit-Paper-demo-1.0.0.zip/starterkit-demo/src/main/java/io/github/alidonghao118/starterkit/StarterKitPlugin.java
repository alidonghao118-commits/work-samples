package io.github.alidonghao118.starterkit;

import org.bukkit.Material;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import java.io.IOException;
import java.time.Instant;
import java.util.*;
import java.util.logging.Level;

public class StarterKitPlugin extends JavaPlugin implements CommandExecutor {
    private ClaimLedger ledger;
    private long cooldown;

    @Override public void onEnable() {
        saveDefaultConfig();
        cooldown = getConfig().getLong("cooldown-seconds", 86400);
        if (cooldown < 1 || cooldown > 31536000) {
            getLogger().severe("cooldown-seconds must be between 1 and 31536000.");
            getServer().getPluginManager().disablePlugin(this); return;
        }
        try { ledger = new ClaimLedger(getDataFolder().toPath().resolve("claims.properties")); }
        catch (IOException e) {
            getLogger().log(Level.SEVERE, "Could not load claim history. Kit disabled to protect existing claims.", e);
            getServer().getPluginManager().disablePlugin(this); return;
        }
        Objects.requireNonNull(getCommand("starterkit")).setExecutor(this);
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Use /starterkit in game."); return true; }
        if (!player.hasPermission("starterkit.claim")) { player.sendMessage("You don't have access to this kit."); return true; }
        if (args.length != 0) { player.sendMessage("Usage: /starterkit"); return true; }
        long now = Instant.now().getEpochSecond();
        long remaining = ledger.secondsRemaining(player.getUniqueId(), now, cooldown);
        if (remaining > 0) { player.sendMessage("Your next kit is ready in " + remaining + " seconds."); return true; }
        List<Integer> slots = new ArrayList<>();
        ItemStack[] storage = player.getInventory().getStorageContents();
        for (int i = 0; i < storage.length && slots.size() < 3; i++) {
            if (storage[i] == null || storage[i].getType().isAir()) slots.add(i);
        }
        if (slots.size() < 3) { player.sendMessage("Free up 3 inventory slots, then try again."); return true; }
        ItemStack[] kit = {new ItemStack(Material.WOODEN_SWORD), new ItemStack(Material.WOODEN_PICKAXE), new ItemStack(Material.BREAD, 16)};
        try { ledger.record(player.getUniqueId(), now); }
        catch (IOException e) {
            getLogger().log(Level.SEVERE, "Could not save kit claim", e);
            player.sendMessage("Kit storage is unavailable. Please tell a server admin."); return true;
        }
        for (int i = 0; i < kit.length; i++) player.getInventory().setItem(slots.get(i), kit[i]);
        player.sendMessage("Starter kit claimed. Have fun!");
        return true;
    }
}
